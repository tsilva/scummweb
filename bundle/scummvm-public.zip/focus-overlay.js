(function () {
  var canvas = document.getElementById("canvas");

  if (!canvas) {
    return;
  }

  var style = document.createElement("style");
  style.textContent =
    "#focus-overlay{position:fixed;inset:0;z-index:6;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(7,5,4,.52);backdrop-filter:blur(8px)}" +
    "#focus-overlay[hidden]{display:none}" +
    "#focus-overlay-card{max-width:min(92vw,420px);padding:18px 20px;border:1px solid rgba(240,228,192,.24);background:rgba(28,19,14,.94);box-shadow:0 18px 50px rgba(0,0,0,.45);color:#f0e4c0;font:15px/1.45 Georgia,\"Times New Roman\",serif;text-align:center}" +
    "#focus-overlay-card strong{display:block;margin-bottom:8px;font-size:18px;letter-spacing:.04em;text-transform:uppercase}" +
    "#focus-overlay-card p{margin:0;color:rgba(240,228,192,.86)}";
  document.head.appendChild(style);

  var overlay = document.createElement("div");
  overlay.id = "focus-overlay";
  overlay.hidden = true;
  overlay.setAttribute("aria-hidden", "true");
  overlay.innerHTML =
    '<div id="focus-overlay-card" role="status" aria-live="polite"><strong>Focus Lost</strong><p>Click anywhere in this window to restore the in-game cursor.</p></div>';
  document.body.appendChild(overlay);

  function hasDocumentFocus() {
    return (
      document.visibilityState === "visible" &&
      (typeof document.hasFocus !== "function" || document.hasFocus())
    );
  }

  function setOverlayVisible(visible) {
    overlay.hidden = !visible;
    overlay.setAttribute("aria-hidden", String(!visible));
  }

  function focusCanvas() {
    if (typeof canvas.focus !== "function") {
      return;
    }

    try {
      canvas.focus({ preventScroll: true });
    } catch (error) {
      canvas.focus();
    }
  }

  function syncFocusState() {
    var focused = hasDocumentFocus();

    setOverlayVisible(!focused);

    if (focused) {
      focusCanvas();
    }
  }

  function maybeRestoreCanvasFocus() {
    if (!hasDocumentFocus()) {
      return;
    }

    setOverlayVisible(false);
    focusCanvas();
  }

  window.addEventListener("focus", syncFocusState);
  window.addEventListener("blur", syncFocusState);
  window.addEventListener("pageshow", syncFocusState);
  document.addEventListener("visibilitychange", syncFocusState);
  window.addEventListener("pointerdown", maybeRestoreCanvasFocus, true);
  canvas.addEventListener("pointerenter", maybeRestoreCanvasFocus, { passive: true });
  canvas.addEventListener("pointermove", maybeRestoreCanvasFocus, { passive: true });
  overlay.addEventListener("pointerdown", maybeRestoreCanvasFocus);

  setTimeout(syncFocusState, 0);
})();
