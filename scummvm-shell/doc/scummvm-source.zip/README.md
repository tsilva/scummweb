# ScummWEB's modified ScummVM browser runtime

ScummVM v2026.4.0 (7d2709da5136866589f7602f5f5a7b17de03420e), modified by ScummWEB for its browser build dated 2026-11-09.
The modified ScummVM runtime is covered by the GNU GPL version 3 or later.
See COPYING and COPYRIGHT for the license and copyright notices.

Download the matching unmodified ScummVM source from:
https://github.com/scummvm/scummvm/archive/7d2709da5136866589f7602f5f5a7b17de03420e.tar.gz

The ordered patches in patches/scummvm/ and the browser build scripts in this
archive complete the source offer for the identified runtime. The adapter scripts
modify the generated JavaScript for browser audio and keyboard handling.
runtime-sha256.json identifies the compiled JavaScript, WebAssembly and engine
plugins served by this build.

To rebuild, extract this archive and run these commands from its root:

    git init
    bash scripts/build_scummvm_web.sh --compile-only

The script checks out the exact ScummVM revision, applies the patches, installs
Emscripten 4.0.10, and builds the runtime in vendor/scummvm-v2026.4.0/build-emscripten.
It uses Git, Bash, curl, Python 3, CMake and standard build tools. It does not need
any game data. Third-party library source archives are in dependencies/.
The Emscripten runtime and port build recipes are at:
https://github.com/emscripten-core/emscripten/archive/refs/tags/4.0.10.tar.gz

The JPEG implementation is based in part on the work of the Independent JPEG Group.
